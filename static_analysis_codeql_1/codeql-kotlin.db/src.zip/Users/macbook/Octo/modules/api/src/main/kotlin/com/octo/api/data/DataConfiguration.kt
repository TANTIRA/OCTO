package com.octo.api.data

import com.octo.ingestion.persistence.JdbcTimeSeriesStore
import com.octo.ingestion.persistence.TimeSeriesQuery
import com.octo.ingestion.persistence.TimeSeriesReader
import com.octo.persistence.TenantScope
import org.springframework.beans.factory.ObjectProvider
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import java.util.UUID
import javax.sql.DataSource

/** Wires the time-series reader like `AccessConfiguration`: resolved lazily so a context without a datasource still starts. */
@Configuration(proxyBeanMethods = false)
class DataConfiguration {
    @Bean
    fun jdbcTimeSeriesReader(dataSource: ObjectProvider<DataSource>): TimeSeriesReader {
        val store by lazy { JdbcTimeSeriesStore(dataSource.getObject()) }
        return object : TimeSeriesReader {
            override fun datasetTenant(
                datasetId: UUID,
                scope: TenantScope,
            ) = store.datasetTenant(datasetId, scope)

            override fun query(
                query: TimeSeriesQuery,
                scope: TenantScope,
            ) = store.query(query, scope)
        }
    }
}
