package com.octo.api

import com.octo.api.ingestion.HeliusWebhookAuthFilter
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.core.annotation.Order
import org.springframework.core.env.Environment
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity
import org.springframework.security.config.http.SessionCreationPolicy
import org.springframework.security.oauth2.jose.jws.SignatureAlgorithm
import org.springframework.security.oauth2.jwt.JwtValidators
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder
import org.springframework.security.web.SecurityFilterChain
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter

/**
 * Auth boundary for the REST API (AGENTS.md: auth endpoints are T2).
 *
 * The service is a stateless resource server: requests are authenticated by bearer JWTs verified
 * against the issuer's JWKS (`AUTH_JWKS_URL`), with issuer validation when `AUTH_ISSUER` is set.
 * Actuator health (including the liveness and readiness probes) and info stay public so probes and the
 * compose healthcheck keep working; metrics and prometheus need a bearer token like everything else.
 *
 * When no JWKS URL is configured the chain still requires authentication on every endpoint —
 * there is no unauthenticated fallback, so a misconfigured environment fails closed.
 */
@Configuration
@EnableWebSecurity
class SecurityConfig {
    /**
     * Vendor callbacks cannot carry a user JWT, so the webhook path gets its own chain ahead
     * of the resource-server chain: it matches only `/api/v1/ingestion/webhooks/helius` and
     * authenticates the request by shared secret (`HELIUS_WEBHOOK_SECRET`). Every other
     * request falls through to the JWT chain below — this chain widens nothing.
     */
    @Bean
    @Order(1)
    fun heliusWebhookFilterChain(
        http: HttpSecurity,
        env: Environment,
    ): SecurityFilterChain {
        http
            .securityMatcher("/api/v1/ingestion/webhooks/helius")
            .csrf { it.disable() }
            .sessionManagement { it.sessionCreationPolicy(SessionCreationPolicy.STATELESS) }
            .authorizeHttpRequests { it.anyRequest().authenticated() }
            .addFilterBefore(
                HeliusWebhookAuthFilter(env.getProperty("HELIUS_WEBHOOK_SECRET")),
                UsernamePasswordAuthenticationFilter::class.java,
            )
        return http.build()
    }

    @Bean
    @Order(2)
    fun securityFilterChain(
        http: HttpSecurity,
        env: Environment,
    ): SecurityFilterChain {
        http
            .csrf { it.disable() }
            .sessionManagement { it.sessionCreationPolicy(SessionCreationPolicy.STATELESS) }
            .authorizeHttpRequests {
                it
                    .requestMatchers("/actuator/health", "/actuator/health/**", "/actuator/info")
                    .permitAll()
                    .anyRequest()
                    .authenticated()
            }

        val jwksUri = env.getProperty("AUTH_JWKS_URL")?.takeIf(String::isNotBlank)
        if (jwksUri != null) {
            // Supabase GoTrue signs ES256 (JWT_KEYS/JWT_JWKS keypair); the
            // builder defaults to expecting RS256, so the algorithm must be
            // declared or every token is rejected as "another algorithm
            // expected" regardless of which keys the JWKS serves.
            val decoder =
                NimbusJwtDecoder
                    .withJwkSetUri(jwksUri)
                    .jwsAlgorithm(SignatureAlgorithm.ES256)
                    .build()
            env
                .getProperty("AUTH_ISSUER")
                ?.takeIf(String::isNotBlank)
                ?.let { decoder.setJwtValidator(JwtValidators.createDefaultWithIssuer(it)) }
            http.oauth2ResourceServer { resourceServer ->
                resourceServer.jwt { jwt -> jwt.decoder(decoder) }
            }
        }
        return http.build()
    }
}
